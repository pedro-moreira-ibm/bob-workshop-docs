# Backend Setup Guide

## Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

## Installation Steps

### 1. Create Virtual Environment
```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python -m venv venv
```

### 2. Activate Virtual Environment

**On macOS/Linux:**
```bash
source venv/bin/activate
```

**On Windows:**
```bash
venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the Application
```bash
python app.py
```

The server will start on `http://localhost:5000`

## API Endpoints

### Health Check
```bash
curl http://localhost:5000/api/health
```

### Get All Todos
```bash
curl http://localhost:5000/api/todos
```

### Create a Todo
```bash
curl -X POST http://localhost:5000/api/todos \
  -H "Content-Type: application/json" \
  -d '{"title":"Buy groceries","description":"Milk, eggs, bread"}'
```

### Update a Todo
```bash
curl -X PUT http://localhost:5000/api/todos/1 \
  -H "Content-Type: application/json" \
  -d '{"completed":true}'
```

### Delete a Todo
```bash
curl -X DELETE http://localhost:5000/api/todos/1
```

## Database

The SQLite database (`todos.db`) will be created automatically in the backend directory when you first run the application.

## Troubleshooting

### Port Already in Use
If port 5000 is already in use, modify the port in `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

### Module Not Found Errors
Make sure you've activated the virtual environment and installed all dependencies:
```bash
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

### Database Issues
If you encounter database issues, delete the `todos.db` file and restart the application. It will be recreated automatically.

## Running Tests

### Quick Test Run
```bash
# Using the test script (recommended)
./run_tests.sh  # macOS/Linux
run_tests.bat   # Windows

# Or using pytest directly
pytest

# With coverage report
pytest --cov=. --cov-report=term-missing --cov-report=html
```

### View Coverage Report
After running tests with coverage, open the HTML report:
```bash
open htmlcov/index.html  # macOS
start htmlcov/index.html # Windows
xdg-open htmlcov/index.html # Linux
```

For detailed testing documentation, see [TESTING.md](TESTING.md)

## Development Mode

The application runs in debug mode by default, which provides:
- Auto-reload on code changes
- Detailed error messages
- Interactive debugger

**Note:** Disable debug mode in production by changing `debug=False` in `app.py`.