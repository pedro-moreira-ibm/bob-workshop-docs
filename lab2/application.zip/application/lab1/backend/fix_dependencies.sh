#!/bin/bash

# Fix Flask dependencies installation
echo "=========================================="
echo "Installing Flask Dependencies"
echo "=========================================="
echo ""

# Make sure we're in the backend directory
cd "$(dirname "$0")"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ Virtual environment not found!"
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo ""
echo "Installing Flask and dependencies..."
pip install -r requirements.txt

echo ""
echo "=========================================="
echo "✅ Installation Complete!"
echo "=========================================="
echo ""
echo "Installed packages:"
pip list | grep -E "Flask|pytest|coverage"

echo ""
echo "You can now run the server with:"
echo "  python app.py"
echo ""
echo "Or use the startup script:"
echo "  ./start_server.sh"

# Made with Bob
