#!/bin/bash

# Run the Flask app using the correct Python interpreter
# This script ensures we use the venv's Python, not an aliased system Python

cd "$(dirname "$0")"

# Activate virtual environment
source venv/bin/activate

# Use python3 explicitly to avoid shell aliases
python3 app.py

# Made with Bob
