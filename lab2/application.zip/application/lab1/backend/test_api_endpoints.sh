#!/bin/bash

# Test all API endpoints with curl
# This script assumes the Flask server is running on localhost:5000

API_BASE="http://localhost:5001/api"

echo "================================"
echo "Testing Todo API Endpoints"
echo "================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test 1: Health Check
echo -e "${BLUE}1. Testing Health Check (GET /api/health)${NC}"
curl -s -X GET "$API_BASE/health" | python3 -m json.tool
echo ""
echo ""

# Test 2: Get all todos (should be empty initially)
echo -e "${BLUE}2. Testing Get All Todos (GET /api/todos)${NC}"
curl -s -X GET "$API_BASE/todos" | python3 -m json.tool
echo ""
echo ""

# Test 3: Create first todo
echo -e "${BLUE}3. Testing Create Todo (POST /api/todos)${NC}"
echo "Creating: 'Buy groceries'"
TODO1=$(curl -s -X POST "$API_BASE/todos" \
  -H "Content-Type: application/json" \
  -d '{"title":"Buy groceries","description":"Milk, eggs, bread"}')
echo "$TODO1" | python3 -m json.tool
TODO1_ID=$(echo "$TODO1" | python3 -c "import sys, json; print(json.load(sys.stdin)['id'])")
echo ""
echo ""

# Test 4: Create second todo
echo -e "${BLUE}4. Testing Create Another Todo (POST /api/todos)${NC}"
echo "Creating: 'Finish project'"
TODO2=$(curl -s -X POST "$API_BASE/todos" \
  -H "Content-Type: application/json" \
  -d '{"title":"Finish project","description":"Complete the todo app"}')
echo "$TODO2" | python3 -m json.tool
TODO2_ID=$(echo "$TODO2" | python3 -c "import sys, json; print(json.load(sys.stdin)['id'])")
echo ""
echo ""

# Test 5: Get all todos (should show 2 todos)
echo -e "${BLUE}5. Testing Get All Todos Again (GET /api/todos)${NC}"
curl -s -X GET "$API_BASE/todos" | python3 -m json.tool
echo ""
echo ""

# Test 6: Get single todo
echo -e "${BLUE}6. Testing Get Single Todo (GET /api/todos/$TODO1_ID)${NC}"
curl -s -X GET "$API_BASE/todos/$TODO1_ID" | python3 -m json.tool
echo ""
echo ""

# Test 7: Update todo (mark as completed)
echo -e "${BLUE}7. Testing Update Todo (PUT /api/todos/$TODO1_ID)${NC}"
echo "Marking todo $TODO1_ID as completed"
curl -s -X PUT "$API_BASE/todos/$TODO1_ID" \
  -H "Content-Type: application/json" \
  -d '{"completed":true}' | python3 -m json.tool
echo ""
echo ""

# Test 8: Update todo (change title and description)
echo -e "${BLUE}8. Testing Update Todo Title (PUT /api/todos/$TODO2_ID)${NC}"
echo "Updating todo $TODO2_ID"
curl -s -X PUT "$API_BASE/todos/$TODO2_ID" \
  -H "Content-Type: application/json" \
  -d '{"title":"Finish project - UPDATED","description":"Complete the todo app with tests"}' | python3 -m json.tool
echo ""
echo ""

# Test 9: Get all todos (should show updates)
echo -e "${BLUE}9. Testing Get All Todos After Updates (GET /api/todos)${NC}"
curl -s -X GET "$API_BASE/todos" | python3 -m json.tool
echo ""
echo ""

# Test 10: Delete a todo
echo -e "${BLUE}10. Testing Delete Todo (DELETE /api/todos/$TODO1_ID)${NC}"
echo "Deleting todo $TODO1_ID"
curl -s -X DELETE "$API_BASE/todos/$TODO1_ID" | python3 -m json.tool
echo ""
echo ""

# Test 11: Get all todos (should show only 1 todo)
echo -e "${BLUE}11. Testing Get All Todos After Delete (GET /api/todos)${NC}"
curl -s -X GET "$API_BASE/todos" | python3 -m json.tool
echo ""
echo ""

# Test 12: Try to get deleted todo (should return 404)
echo -e "${BLUE}12. Testing Get Deleted Todo - Should Return 404 (GET /api/todos/$TODO1_ID)${NC}"
curl -s -X GET "$API_BASE/todos/$TODO1_ID" | python3 -m json.tool
echo ""
echo ""

echo -e "${GREEN}================================${NC}"
echo -e "${GREEN}All API Endpoint Tests Complete!${NC}"
echo -e "${GREEN}================================${NC}"

# Made with Bob
