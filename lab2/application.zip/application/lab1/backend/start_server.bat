@echo off
REM Start the Flask Todo API server
REM Usage: start_server.bat

echo ================================
echo Starting Flask Todo API Server
echo ================================
echo.

REM Check if virtual environment exists
if not exist "venv" (
    echo Virtual environment not found!
    echo Run: python -m venv venv
    exit /b 1
)

REM Activate virtual environment
echo Activating virtual environment...
call venv\Scripts\activate

REM Check if dependencies are installed
python -c "import flask" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Flask not installed!
    echo Run: pip install -r requirements.txt
    exit /b 1
)

echo Environment ready
echo.
echo Starting server on http://localhost:5000
echo Press Ctrl+C to stop the server
echo.
echo API Endpoints:
echo   - GET    http://localhost:5000/api/todos
echo   - POST   http://localhost:5000/api/todos
echo   - PUT    http://localhost:5000/api/todos/^<id^>
echo   - DELETE http://localhost:5000/api/todos/^<id^>
echo   - GET    http://localhost:5000/api/health
echo.
echo ================================
echo.

REM Run the Flask app
python app.py

@REM Made with Bob
