#!/bin/bash

# Start the Flask Todo API server
# Usage: ./start_server.sh

echo "================================"
echo "Starting Flask Todo API Server"
echo "================================"
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "❌ Virtual environment not found!"
    echo "Run: python3 -m venv venv"
    exit 1
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Check if dependencies are installed
if ! python -c "import flask" 2>/dev/null; then
    echo "❌ Flask not installed!"
    echo "Run: pip install -r requirements.txt"
    exit 1
fi

echo "✅ Environment ready"
echo ""
echo "Starting server on http://localhost:5000"
echo "Press Ctrl+C to stop the server"
echo ""
echo "API Endpoints:"
echo "  - GET    http://localhost:5000/api/todos"
echo "  - POST   http://localhost:5000/api/todos"
echo "  - PUT    http://localhost:5000/api/todos/<id>"
echo "  - DELETE http://localhost:5000/api/todos/<id>"
echo "  - GET    http://localhost:5000/api/health"
echo ""
echo "================================"
echo ""

# Run the Flask app
python app.py

# Made with Bob
