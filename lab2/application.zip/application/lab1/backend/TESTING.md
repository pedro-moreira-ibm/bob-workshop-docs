# Testing Guide

## Overview
This document describes the testing strategy and how to run tests for the Todo API.

## Test Coverage
The test suite includes comprehensive unit tests for:
- ✅ All API endpoints (GET, POST, PUT, DELETE)
- ✅ Database models and methods
- ✅ Error handling and validation
- ✅ Edge cases and boundary conditions
- ✅ HTTP status codes
- ✅ JSON response formats

**Target Coverage: 90%+**

## Test Structure

### Test Files
- `test_app.py` - Main test file containing all unit tests

### Test Classes
1. **TodoAPITestCase** - Tests for all API endpoints
2. **TodoModelTestCase** - Tests for database models

## Running Tests

### Prerequisites
```bash
# Activate virtual environment
source venv/bin/activate  # macOS/Linux
# or
venv\Scripts\activate  # Windows

# Install dependencies including test tools
pip install -r requirements.txt
```

### Run All Tests
```bash
# Using pytest (recommended)
pytest

# Using unittest
python -m unittest test_app.py
```

### Run Tests with Coverage
```bash
# Run tests with coverage report
pytest --cov=. --cov-report=term-missing

# Generate HTML coverage report
pytest --cov=. --cov-report=html

# View HTML report
open htmlcov/index.html  # macOS
start htmlcov/index.html  # Windows
```

### Run Specific Tests
```bash
# Run a specific test class
pytest test_app.py::TodoAPITestCase

# Run a specific test method
pytest test_app.py::TodoAPITestCase::test_create_todo_success

# Run tests matching a pattern
pytest -k "create_todo"
```

### Verbose Output
```bash
# Show detailed test output
pytest -v

# Show print statements
pytest -s
```

## Test Cases

### API Endpoint Tests

#### GET /api/todos
- ✅ Get empty list when no todos exist
- ✅ Get all todos with correct ordering (newest first)
- ✅ Verify JSON response format

#### GET /api/todos/<id>
- ✅ Get single todo by ID
- ✅ Return 404 for non-existent todo

#### POST /api/todos
- ✅ Create todo with title and description
- ✅ Create todo with only title
- ✅ Fail when title is missing (400)
- ✅ Fail when title is empty/whitespace (400)
- ✅ Fail when no data provided (400)
- ✅ Strip whitespace from inputs
- ✅ Return 201 status code on success

#### PUT /api/todos/<id>
- ✅ Update todo title
- ✅ Update todo description
- ✅ Update todo completed status
- ✅ Update multiple fields at once
- ✅ Fail when title is empty (400)
- ✅ Fail when no data provided (400)
- ✅ Return 404 for non-existent todo
- ✅ Strip whitespace from inputs
- ✅ Boolean conversion for completed field

#### DELETE /api/todos/<id>
- ✅ Delete existing todo
- ✅ Return 404 for non-existent todo
- ✅ Verify todo is actually deleted

#### GET /api/health
- ✅ Health check returns 200
- ✅ Returns correct status message

### Model Tests
- ✅ Todo model default values
- ✅ Todo model with all fields
- ✅ Todo model string representation
- ✅ Todo model to_dict() method

### Error Handling Tests
- ✅ 404 error handler for invalid routes
- ✅ Database rollback on errors
- ✅ Proper error messages in responses

## Coverage Report Example

```
Name            Stmts   Miss  Cover   Missing
---------------------------------------------
app.py            95      2    98%    143-144
database.py       11      0   100%
models.py         20      0   100%
---------------------------------------------
TOTAL            126      2    98%
```

## Continuous Integration

### GitHub Actions Example
```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.8'
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
      - name: Run tests with coverage
        run: |
          pytest --cov=. --cov-report=xml
      - name: Upload coverage
        uses: codecov/codecov-action@v2
```

## Best Practices

### Writing Tests
1. **Arrange-Act-Assert**: Structure tests clearly
2. **Isolation**: Each test should be independent
3. **Descriptive Names**: Test names should describe what they test
4. **Edge Cases**: Test boundary conditions and error cases
5. **Clean Up**: Use setUp() and tearDown() properly

### Test Data
- Use in-memory SQLite database for tests
- Create fresh database for each test
- Clean up after each test

### Assertions
- Use specific assertions (assertEqual, assertTrue, etc.)
- Check both success and error cases
- Verify HTTP status codes
- Validate JSON response structure

## Troubleshooting

### Import Errors
If you get import errors, ensure you're in the backend directory:
```bash
cd backend
pytest
```

### Database Errors
Tests use an in-memory database, so no cleanup is needed. If you encounter issues:
```bash
# Remove any test database files
rm -f test_*.db
```

### Coverage Not Meeting Target
If coverage is below 90%:
1. Run with missing lines report: `pytest --cov=. --cov-report=term-missing`
2. Identify uncovered lines
3. Add tests for those code paths

## Test Metrics

### Current Test Statistics
- **Total Tests**: 35+
- **Test Classes**: 2
- **Coverage Target**: 90%
- **Expected Coverage**: 95%+

### Test Execution Time
- Average: < 1 second
- All tests should complete in under 5 seconds

## Adding New Tests

When adding new features:
1. Write tests first (TDD approach)
2. Ensure tests fail initially
3. Implement feature
4. Verify tests pass
5. Check coverage remains above 90%

### Test Template
```python
def test_new_feature(self):
    """Test description."""
    # Arrange
    # Set up test data
    
    # Act
    # Execute the code being tested
    
    # Assert
    # Verify expected results
    self.assertEqual(expected, actual)
```

## Resources

- [pytest Documentation](https://docs.pytest.org/)
- [Flask Testing](https://flask.palletsprojects.com/en/latest/testing/)
- [Coverage.py](https://coverage.readthedocs.io/)