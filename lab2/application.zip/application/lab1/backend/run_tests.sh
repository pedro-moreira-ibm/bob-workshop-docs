#!/bin/bash

# Run tests with coverage for Todo API
# Usage: ./run_tests.sh

echo "================================"
echo "Running Todo API Tests"
echo "================================"
echo ""

# Check if virtual environment is activated
if [[ -z "$VIRTUAL_ENV" ]]; then
    echo "⚠️  Warning: Virtual environment not activated"
    echo "Run: source venv/bin/activate"
    echo ""
fi

# Run tests with coverage
echo "Running tests with coverage..."
pytest --cov=. --cov-report=term-missing --cov-report=html --cov-fail-under=90

# Check exit code
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ All tests passed!"
    echo ""
    echo "📊 Coverage report generated in htmlcov/index.html"
    echo "   Open with: open htmlcov/index.html (macOS) or start htmlcov/index.html (Windows)"
else
    echo ""
    echo "❌ Tests failed or coverage below 90%"
    exit 1
fi

# Made with Bob
