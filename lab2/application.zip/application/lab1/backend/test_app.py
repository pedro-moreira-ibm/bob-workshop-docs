"""Unit tests for the Todo API."""
import unittest
import json
from app import create_app
from database import db
from models import Todo


class TodoAPITestCase(unittest.TestCase):
    """Test case for Todo API endpoints."""
    
    def setUp(self):
        """Set up test client and initialize test database."""
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
    
    def tearDown(self):
        """Clean up after each test."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_health_check(self):
        """Test the health check endpoint."""
        response = self.client.get('/api/health')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'healthy')
        self.assertIn('message', data)
    
    def test_get_todos_empty(self):
        """Test getting todos when database is empty."""
        response = self.client.get('/api/todos')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data, [])
    
    def test_create_todo_success(self):
        """Test creating a new todo successfully."""
        todo_data = {
            'title': 'Test Todo',
            'description': 'Test Description'
        }
        response = self.client.post(
            '/api/todos',
            data=json.dumps(todo_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertEqual(data['title'], 'Test Todo')
        self.assertEqual(data['description'], 'Test Description')
        self.assertFalse(data['completed'])
        self.assertIn('id', data)
        self.assertIn('created_at', data)
    
    def test_create_todo_without_description(self):
        """Test creating a todo without description."""
        todo_data = {'title': 'Test Todo'}
        response = self.client.post(
            '/api/todos',
            data=json.dumps(todo_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertEqual(data['title'], 'Test Todo')
        self.assertEqual(data['description'], '')
    
    def test_create_todo_missing_title(self):
        """Test creating a todo without title (should fail)."""
        todo_data = {'description': 'Test Description'}
        response = self.client.post(
            '/api/todos',
            data=json.dumps(todo_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
        self.assertEqual(data['error'], 'Title is required')
    
    def test_create_todo_empty_title(self):
        """Test creating a todo with empty title (should fail)."""
        todo_data = {'title': '   '}
        response = self.client.post(
            '/api/todos',
            data=json.dumps(todo_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_create_todo_no_data(self):
        """Test creating a todo with no data (should fail)."""
        response = self.client.post(
            '/api/todos',
            data=json.dumps({}),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_get_todos_with_data(self):
        """Test getting todos when database has data."""
        # Create test todos
        with self.app.app_context():
            todo1 = Todo(title='Todo 1', description='Description 1')
            todo2 = Todo(title='Todo 2', description='Description 2')
            db.session.add(todo1)
            db.session.add(todo2)
            db.session.commit()
        
        response = self.client.get('/api/todos')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(len(data), 2)
        # Verify todos are ordered by created_at desc (newest first)
        self.assertEqual(data[0]['title'], 'Todo 2')
        self.assertEqual(data[1]['title'], 'Todo 1')
    
    def test_get_single_todo_success(self):
        """Test getting a single todo by ID."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Test Todo', description='Test Description')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        response = self.client.get(f'/api/todos/{todo_id}')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['title'], 'Test Todo')
        self.assertEqual(data['description'], 'Test Description')
    
    def test_get_single_todo_not_found(self):
        """Test getting a non-existent todo."""
        response = self.client.get('/api/todos/999')
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_update_todo_title(self):
        """Test updating a todo's title."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Original Title', description='Description')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        update_data = {'title': 'Updated Title'}
        response = self.client.put(
            f'/api/todos/{todo_id}',
            data=json.dumps(update_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['title'], 'Updated Title')
        self.assertEqual(data['description'], 'Description')
    
    def test_update_todo_description(self):
        """Test updating a todo's description."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Title', description='Original Description')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        update_data = {'description': 'Updated Description'}
        response = self.client.put(
            f'/api/todos/{todo_id}',
            data=json.dumps(update_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['description'], 'Updated Description')
    
    def test_update_todo_completed(self):
        """Test updating a todo's completed status."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Title', completed=False)
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        update_data = {'completed': True}
        response = self.client.put(
            f'/api/todos/{todo_id}',
            data=json.dumps(update_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(data['completed'])
    
    def test_update_todo_multiple_fields(self):
        """Test updating multiple fields at once."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Original', description='Original Desc', completed=False)
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        update_data = {
            'title': 'Updated',
            'description': 'Updated Desc',
            'completed': True
        }
        response = self.client.put(
            f'/api/todos/{todo_id}',
            data=json.dumps(update_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['title'], 'Updated')
        self.assertEqual(data['description'], 'Updated Desc')
        self.assertTrue(data['completed'])
    
    def test_update_todo_empty_title(self):
        """Test updating a todo with empty title (should fail)."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Original Title')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        update_data = {'title': '   '}
        response = self.client.put(
            f'/api/todos/{todo_id}',
            data=json.dumps(update_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_update_todo_no_data(self):
        """Test updating a todo with no data (should fail)."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Title')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        response = self.client.put(
            f'/api/todos/{todo_id}',
            data=json.dumps({}),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_update_todo_not_found(self):
        """Test updating a non-existent todo."""
        update_data = {'title': 'Updated'}
        response = self.client.put(
            '/api/todos/999',
            data=json.dumps(update_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_delete_todo_success(self):
        """Test deleting a todo successfully."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='To Delete')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        response = self.client.delete(f'/api/todos/{todo_id}')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertIn('message', data)
        
        # Verify todo is deleted
        response = self.client.get(f'/api/todos/{todo_id}')
        self.assertEqual(response.status_code, 404)
    
    def test_delete_todo_not_found(self):
        """Test deleting a non-existent todo."""
        response = self.client.delete('/api/todos/999')
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_404_error_handler(self):
        """Test 404 error handler for invalid routes."""
        response = self.client.get('/api/invalid-route')
        self.assertEqual(response.status_code, 404)
        data = json.loads(response.data)
        self.assertIn('error', data)
    
    def test_todo_model_repr(self):
        """Test Todo model string representation."""
        with self.app.app_context():
            todo = Todo(title='Test Todo')
            db.session.add(todo)
            db.session.commit()
            self.assertIn('Test Todo', repr(todo))
            self.assertIn(str(todo.id), repr(todo))
    
    def test_todo_model_to_dict(self):
        """Test Todo model to_dict method."""
        with self.app.app_context():
            todo = Todo(title='Test', description='Desc', completed=True)
            db.session.add(todo)
            db.session.commit()
            
            todo_dict = todo.to_dict()
            self.assertIn('id', todo_dict)
            self.assertEqual(todo_dict['title'], 'Test')
            self.assertEqual(todo_dict['description'], 'Desc')
            self.assertTrue(todo_dict['completed'])
            self.assertIn('created_at', todo_dict)
    
    def test_create_todo_with_whitespace(self):
        """Test creating a todo with whitespace in title and description."""
        todo_data = {
            'title': '  Test Todo  ',
            'description': '  Test Description  '
        }
        response = self.client.post(
            '/api/todos',
            data=json.dumps(todo_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        # Verify whitespace is stripped
        self.assertEqual(data['title'], 'Test Todo')
        self.assertEqual(data['description'], 'Test Description')
    
    def test_update_todo_with_whitespace(self):
        """Test updating a todo with whitespace."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Original')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        update_data = {
            'title': '  Updated  ',
            'description': '  New Desc  '
        }
        response = self.client.put(
            f'/api/todos/{todo_id}',
            data=json.dumps(update_data),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        # Verify whitespace is stripped
        self.assertEqual(data['title'], 'Updated')
        self.assertEqual(data['description'], 'New Desc')
    
    def test_completed_boolean_conversion(self):
        """Test that completed field properly converts to boolean."""
        # Create a test todo
        with self.app.app_context():
            todo = Todo(title='Test')
            db.session.add(todo)
            db.session.commit()
            todo_id = todo.id
        
        # Test with various truthy/falsy values
        test_cases = [
            (True, True),
            (False, False),
            (1, True),
            (0, False),
            ('true', True),
            ('false', True),  # Non-empty string is truthy
            ('', False)
        ]
        
        for input_val, expected in test_cases:
            update_data = {'completed': input_val}
            response = self.client.put(
                f'/api/todos/{todo_id}',
                data=json.dumps(update_data),
                content_type='application/json'
            )
            self.assertEqual(response.status_code, 200)
            data = json.loads(response.data)
            self.assertEqual(data['completed'], expected)


class TodoModelTestCase(unittest.TestCase):
    """Test case for Todo model."""
    
    def setUp(self):
        """Set up test database."""
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        
        with self.app.app_context():
            db.create_all()
    
    def tearDown(self):
        """Clean up after each test."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_todo_default_values(self):
        """Test that Todo model has correct default values."""
        with self.app.app_context():
            todo = Todo(title='Test')
            db.session.add(todo)
            db.session.commit()
            
            self.assertIsNotNone(todo.id)
            self.assertEqual(todo.title, 'Test')
            self.assertEqual(todo.description, None)
            self.assertFalse(todo.completed)
            self.assertIsNotNone(todo.created_at)
    
    def test_todo_with_all_fields(self):
        """Test creating a Todo with all fields."""
        with self.app.app_context():
            todo = Todo(
                title='Complete Todo',
                description='Full description',
                completed=True
            )
            db.session.add(todo)
            db.session.commit()
            
            self.assertEqual(todo.title, 'Complete Todo')
            self.assertEqual(todo.description, 'Full description')
            self.assertTrue(todo.completed)


if __name__ == '__main__':
    unittest.main()

# Made with Bob
