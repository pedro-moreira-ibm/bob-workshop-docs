@echo off
REM Run tests with coverage for Todo API
REM Usage: run_tests.bat

echo ================================
echo Running Todo API Tests
echo ================================
echo.

REM Check if virtual environment is activated
if "%VIRTUAL_ENV%"=="" (
    echo Warning: Virtual environment not activated
    echo Run: venv\Scripts\activate
    echo.
)

REM Run tests with coverage
echo Running tests with coverage...
pytest --cov=. --cov-report=term-missing --cov-report=html --cov-fail-under=90

REM Check exit code
if %ERRORLEVEL% EQU 0 (
    echo.
    echo All tests passed!
    echo.
    echo Coverage report generated in htmlcov\index.html
    echo Open with: start htmlcov\index.html
) else (
    echo.
    echo Tests failed or coverage below 90%%
    exit /b 1
)

@REM Made with Bob
