# Flask Backend Troubleshooting Guide

## Common Issues and Solutions

### 1. ModuleNotFoundError: No module named 'flask'

**Problem**: Flask or dependencies not installed

**Solution**:
```bash
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Address already in use (Port 5001)

**Problem**: Another process is using port 5001

**Solution A - Kill the process**:
```bash
# Find the process using port 5001
lsof -ti:5001 | xargs kill -9

# Or on Windows
netstat -ano | findstr :5001
taskkill /PID <PID> /F
```

**Solution B - Use a different port**:
Edit `backend/app.py` line 145:
```python
app.run(debug=True, host='0.0.0.0', port=5002)  # Change to 5002
```

Then update `frontend/js/app.js` line 9:
```javascript
const API_BASE_URL = 'http://localhost:5002/api';  // Change to 5002
```

### 3. ImportError: cannot import name 'db' from 'database'

**Problem**: Circular import or module structure issue

**Solution**: Make sure you're running from the backend directory:
```bash
cd backend
python app.py
```

### 4. Database locked or permission denied

**Problem**: SQLite database file has permission issues

**Solution**:
```bash
cd backend
rm todos.db  # Delete the database
python app.py  # Will recreate automatically
```

### 5. CORS errors in browser console

**Problem**: Frontend can't communicate with backend

**Solution**: Verify Flask-CORS is installed:
```bash
pip install Flask-CORS==4.0.0
```

Check that CORS is enabled in `app.py`:
```python
from flask_cors import CORS
CORS(app)
```

### 6. Virtual environment not activated

**Problem**: Using system Python instead of venv

**Solution**:
```bash
cd backend
source venv/bin/activate  # On macOS/Linux
# OR
venv\Scripts\activate  # On Windows

# Verify with:
which python  # Should show path to venv
```

### 7. Python version incompatibility

**Problem**: Using Python < 3.8

**Solution**:
```bash
python3 --version  # Check version
# If < 3.8, install Python 3.8+
```

### 8. Missing __pycache__ or .pyc files

**Problem**: Python bytecode cache issues

**Solution**:
```bash
cd backend
find . -type d -name __pycache__ -exec rm -r {} +
find . -name "*.pyc" -delete
```

## Quick Diagnostic Commands

Run these to check your setup:

```bash
# Check Python version
python3 --version

# Check if virtual environment is active
which python

# Check installed packages
pip list

# Check if Flask is importable
python -c "import flask; print(flask.__version__)"

# Check if port 5001 is available
lsof -i :5001  # macOS/Linux
netstat -ano | findstr :5001  # Windows

# Test database creation
python -c "from database import db; from app import app; app.app_context().push(); db.create_all(); print('DB OK')"
```

## Still Having Issues?

1. **Check the full error traceback** - The last line shows the error, but the traceback shows where it originated
2. **Verify file structure** - Make sure all files are in the correct locations
3. **Check file permissions** - Ensure you have read/write access to the backend directory
4. **Try a fresh install**:
   ```bash
   cd backend
   rm -rf venv
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python app.py
   ```

## Getting Help

When reporting an issue, include:
1. Full error message and traceback
2. Python version (`python3 --version`)
3. Operating system
4. Output of `pip list`
5. Whether virtual environment is activated