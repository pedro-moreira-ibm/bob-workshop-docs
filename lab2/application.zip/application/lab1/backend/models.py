"""Database models for the Todo application."""
from datetime import datetime
from database import db


class Todo(db.Model):
    """Todo model representing a single todo item."""
    
    __tablename__ = 'todos'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    completed = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        """String representation of Todo."""
        return f'<Todo {self.id}: {self.title}>'
    
    def to_dict(self):
        """Convert Todo object to dictionary for JSON serialization."""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'completed': self.completed,
            'created_at': self.created_at.isoformat()
        }

# Made with Bob
