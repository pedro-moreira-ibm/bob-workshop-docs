# GitHub Setup Instructions

## Step 1: Create GitHub Repository

You have two options to create the repository:

### Option A: Using GitHub CLI (gh)
```bash
# Install GitHub CLI if you haven't already (macOS)
brew install gh

# Authenticate with GitHub
gh auth login

# Create the repository
gh repo create bob-todo-app --public --source=. --remote=origin --push
```

### Option B: Using GitHub Web Interface
1. Go to https://github.com/new
2. Repository name: `bob-todo-app`
3. Description: "Full-stack Todo application with Flask backend and JavaScript frontend"
4. Choose Public or Private
5. **DO NOT** initialize with README, .gitignore, or license (we already have these)
6. Click "Create repository"

## Step 2: Push Your Code (if using Option B)

After creating the repository via web interface, run these commands:

```bash
# Add the remote repository
git remote add origin https://github.com/YOUR_USERNAME/bob-todo-app.git

# Push your code to GitHub
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

## Step 3: Verify

Visit your repository at:
```
https://github.com/YOUR_USERNAME/bob-todo-app
```

You should see:
- ✅ 27 files committed
- ✅ README.md displayed on the main page
- ✅ Complete project structure with backend and frontend folders
- ✅ All documentation files

## What's Already Included

Your repository already contains:
- **README.md** - Comprehensive project documentation with:
  - Project overview and features
  - Technology stack
  - Installation instructions
  - API documentation
  - Usage guide
  - Testing instructions
  - Project structure
  - Contributing guidelines

- **.gitignore** - Configured for Python and Node.js

- **Complete codebase** - All 27 files with 6,420 lines of code

## Optional: Add Repository Topics

After pushing, you can add topics to your repository for better discoverability:
1. Go to your repository on GitHub
2. Click the gear icon next to "About"
3. Add topics: `flask`, `python`, `javascript`, `todo-app`, `rest-api`, `sqlite`, `full-stack`

## Optional: Enable GitHub Pages (for frontend demo)

If you want to host the frontend on GitHub Pages:
1. Go to repository Settings → Pages
2. Source: Deploy from a branch
3. Branch: main, folder: /frontend
4. Save

Note: You'll need to update the API_BASE_URL in frontend/js/app.js to point to your deployed backend.