#!/bin/bash

# Script to push the todo app to GitHub
# This script will guide you through creating and pushing to a GitHub repository

echo "=========================================="
echo "GitHub Repository Setup for bob-todo-app"
echo "=========================================="
echo ""

# Check if git is initialized
if [ ! -d .git ]; then
    echo "❌ Error: Git repository not initialized!"
    echo "Run: git init"
    exit 1
fi

echo "✅ Git repository detected"
echo ""

# Check for uncommitted changes
if ! git diff-index --quiet HEAD --; then
    echo "⚠️  Warning: You have uncommitted changes"
    echo "Commit them first with: git add . && git commit -m 'Your message'"
    exit 1
fi

echo "✅ Working tree is clean"
echo ""

# Prompt for GitHub username
echo "Please enter your GitHub username:"
read -r GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    echo "❌ Error: GitHub username is required"
    exit 1
fi

echo ""
echo "=========================================="
echo "Next Steps:"
echo "=========================================="
echo ""
echo "1. Create a new repository on GitHub:"
echo "   - Go to: https://github.com/new"
echo "   - Repository name: bob-todo-app"
echo "   - Description: Full-stack Todo application with Flask backend and JavaScript frontend"
echo "   - Make it Public or Private (your choice)"
echo "   - ⚠️  DO NOT initialize with README, .gitignore, or license"
echo "   - Click 'Create repository'"
echo ""
echo "2. After creating the repository, press Enter to continue..."
read -r

echo ""
echo "Setting up remote repository..."

# Add remote
git remote add origin "https://github.com/$GITHUB_USERNAME/bob-todo-app.git" 2>/dev/null || {
    echo "Remote 'origin' already exists. Updating URL..."
    git remote set-url origin "https://github.com/$GITHUB_USERNAME/bob-todo-app.git"
}

echo "✅ Remote repository configured"
echo ""

# Push to GitHub
echo "Pushing code to GitHub..."
echo "You may be prompted for your GitHub credentials..."
echo ""

if git push -u origin main; then
    echo ""
    echo "=========================================="
    echo "✅ SUCCESS!"
    echo "=========================================="
    echo ""
    echo "Your repository is now available at:"
    echo "https://github.com/$GITHUB_USERNAME/bob-todo-app"
    echo ""
    echo "Next steps:"
    echo "1. Visit your repository to verify all files are there"
    echo "2. Add repository topics: flask, python, javascript, todo-app, rest-api"
    echo "3. Star your own repository! ⭐"
    echo ""
else
    echo ""
    echo "=========================================="
    echo "❌ Push failed"
    echo "=========================================="
    echo ""
    echo "Common issues:"
    echo "1. Authentication failed - You may need to use a Personal Access Token"
    echo "   Generate one at: https://github.com/settings/tokens"
    echo ""
    echo "2. Repository doesn't exist - Make sure you created it on GitHub first"
    echo ""
    echo "3. Permission denied - Check your GitHub credentials"
    echo ""
    echo "Manual push command:"
    echo "git push -u origin main"
    echo ""
fi

# Made with Bob
