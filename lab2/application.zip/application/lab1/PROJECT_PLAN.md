# Todo Application - Project Plan

## Overview
A simple todo application with a Python Flask backend and vanilla JavaScript frontend, featuring basic CRUD operations for a single user.

---

## 1. Project Directory Structure

```
todo-app/
├── backend/
│   ├── app.py                 # Main Flask application
│   ├── models.py              # Database models
│   ├── config.py              # Configuration settings
│   ├── requirements.txt       # Python dependencies
│   └── instance/
│       └── todos.db          # SQLite database (auto-generated)
├── frontend/
│   ├── index.html            # Main HTML file
│   ├── css/
│   │   └── styles.css        # Application styles
│   └── js/
│       └── app.js            # Frontend JavaScript logic
├── .gitignore                # Git ignore file
└── README.md                 # Project documentation
```

### Directory Purpose:
- **backend/**: Contains all Flask server code and database
- **frontend/**: Contains all client-side code (HTML, CSS, JS)
- **instance/**: Flask instance folder for database file

---

## 2. API Endpoints

### Base URL: `http://localhost:5000/api`

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| GET | `/todos` | Get all todos | None | `[{id, title, description, completed, created_at}]` |
| GET | `/todos/<id>` | Get single todo | None | `{id, title, description, completed, created_at}` |
| POST | `/todos` | Create new todo | `{title, description?}` | `{id, title, description, completed, created_at}` |
| PUT | `/todos/<id>` | Update todo | `{title?, description?, completed?}` | `{id, title, description, completed, created_at}` |
| DELETE | `/todos/<id>` | Delete todo | None | `{message: "Todo deleted"}` |

### Response Codes:
- `200 OK`: Successful GET, PUT, DELETE
- `201 Created`: Successful POST
- `400 Bad Request`: Invalid input
- `404 Not Found`: Todo not found
- `500 Internal Server Error`: Server error

---

## 3. Database Schema

### Technology: SQLite (file-based, no separate server needed)

### Table: `todos`

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique identifier |
| title | VARCHAR(200) | NOT NULL | Todo title |
| description | TEXT | NULLABLE | Optional detailed description |
| completed | BOOLEAN | DEFAULT FALSE | Completion status |
| created_at | DATETIME | DEFAULT CURRENT_TIMESTAMP | Creation timestamp |

### SQL Schema:
```sql
CREATE TABLE todos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    completed BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 4. Technology Stack

### Backend Stack:
- **Python 3.8+**: Programming language
- **Flask 3.0+**: Lightweight web framework
- **Flask-CORS**: Handle Cross-Origin Resource Sharing
- **Flask-SQLAlchemy**: ORM for database operations
- **SQLite**: Embedded database (no installation needed)

### Frontend Stack:
- **HTML5**: Semantic markup
- **CSS3**: Styling with Flexbox/Grid
- **Vanilla JavaScript (ES6+)**: No frameworks, pure JS
- **Fetch API**: For HTTP requests to backend

### Development Tools:
- **Python venv**: Virtual environment management
- **pip**: Python package manager
- **Git**: Version control

---

## 5. Key Features

### Backend Features:
- RESTful API design
- JSON request/response format
- CORS enabled for local development
- Error handling and validation
- SQLAlchemy ORM for database operations

### Frontend Features:
- Single-page application (SPA)
- Real-time UI updates
- Form validation
- Responsive design
- Visual feedback for actions (loading states, success/error messages)

### User Capabilities:
- ✅ Add new todos with title and optional description
- ✅ View all todos in a list
- ✅ Mark todos as complete/incomplete
- ✅ Edit existing todos
- ✅ Delete todos
- ✅ See creation timestamps

---

## 6. Implementation Flow

```mermaid
graph TD
    A[Setup Project Structure] --> B[Configure Backend]
    B --> C[Create Database Models]
    C --> D[Implement API Endpoints]
    D --> E[Test Backend with curl/Postman]
    E --> F[Create Frontend HTML]
    F --> G[Implement JavaScript Logic]
    G --> H[Add CSS Styling]
    H --> I[Integration Testing]
    I --> J[Documentation]
```

---

## 7. API Request/Response Examples

### Create Todo (POST /api/todos)
**Request:**
```json
{
  "title": "Buy groceries",
  "description": "Milk, eggs, bread"
}
```

**Response (201):**
```json
{
  "id": 1,
  "title": "Buy groceries",
  "description": "Milk, eggs, bread",
  "completed": false,
  "created_at": "2026-05-07T10:51:00Z"
}
```

### Get All Todos (GET /api/todos)
**Response (200):**
```json
[
  {
    "id": 1,
    "title": "Buy groceries",
    "description": "Milk, eggs, bread",
    "completed": false,
    "created_at": "2026-05-07T10:51:00Z"
  },
  {
    "id": 2,
    "title": "Finish project",
    "description": null,
    "completed": true,
    "created_at": "2026-05-07T09:30:00Z"
  }
]
```

### Update Todo (PUT /api/todos/1)
**Request:**
```json
{
  "completed": true
}
```

**Response (200):**
```json
{
  "id": 1,
  "title": "Buy groceries",
  "description": "Milk, eggs, bread",
  "completed": true,
  "created_at": "2026-05-07T10:51:00Z"
}
```

---

## 8. Configuration Details

### Backend Configuration (config.py)
```python
import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///todos.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
```

### CORS Configuration
- Allow origins: `http://localhost:*`, `http://127.0.0.1:*`
- Allow methods: GET, POST, PUT, DELETE, OPTIONS
- Allow headers: Content-Type

---

## 9. Dependencies

### Backend (requirements.txt)
```
Flask==3.0.0
Flask-CORS==4.0.0
Flask-SQLAlchemy==3.1.1
```

### Frontend
No external dependencies - uses vanilla JavaScript and native browser APIs.

---

## 10. Development Workflow

### Backend Setup:
1. Create virtual environment: `python -m venv venv`
2. Activate: `source venv/bin/activate` (Unix) or `venv\Scripts\activate` (Windows)
3. Install dependencies: `pip install -r requirements.txt`
4. Run server: `python app.py`
5. Server runs on: `http://localhost:5000`

### Frontend Setup:
1. Open `frontend/index.html` in browser, OR
2. Use Python's built-in server: `python -m http.server 8000` from frontend directory
3. Access at: `http://localhost:8000`

---

## 11. Testing Strategy

### Backend Testing:
- Test each endpoint with curl or Postman
- Verify database operations
- Check error handling

### Frontend Testing:
- Test all CRUD operations through UI
- Verify form validation
- Check responsive design on different screen sizes
- Test error scenarios (network failures, invalid input)

### Integration Testing:
- End-to-end user workflows
- Create → Read → Update → Delete cycle
- Multiple todos management

---

## 12. Future Enhancements (Out of Scope)

- User authentication and authorization
- Multiple users support
- Categories/tags for todos
- Due dates and reminders
- Search and filter functionality
- Data persistence to cloud
- Mobile app version
- Real-time collaboration

---

## 13. Security Considerations

For this basic version:
- Input validation on both frontend and backend
- SQL injection prevention (using SQLAlchemy ORM)
- CORS properly configured
- No sensitive data storage

**Note:** For production use, add authentication, HTTPS, environment variables for secrets, and proper error logging.

---

## Success Criteria

The project will be considered complete when:
- ✅ All API endpoints work correctly
- ✅ Frontend can perform all CRUD operations
- ✅ Data persists in SQLite database
- ✅ UI is responsive and user-friendly
- ✅ Error handling works properly
- ✅ Documentation is complete

---

## Estimated Timeline

- Project setup: 30 minutes
- Backend implementation: 1-2 hours
- Frontend implementation: 1-2 hours
- Testing and refinement: 30 minutes
- Documentation: 30 minutes

**Total: 3-5 hours** for a complete, working application