#!/bin/bash

# Script to open the Todo application
# This will open the frontend HTML file in your default browser

echo "=========================================="
echo "Opening Todo Application"
echo "=========================================="
echo ""

# Get the absolute path to the frontend directory
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FRONTEND_PATH="$SCRIPT_DIR/frontend/index.html"

# Check if frontend exists
if [ ! -f "$FRONTEND_PATH" ]; then
    echo "❌ Error: Frontend file not found at $FRONTEND_PATH"
    exit 1
fi

echo "✅ Frontend found"
echo ""
echo "📋 Instructions:"
echo "1. Make sure the Flask backend is running on http://localhost:5001"
echo "   (Run: cd backend && python app.py)"
echo ""
echo "2. Opening frontend in your default browser..."
echo ""

# Open the HTML file in the default browser
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    open "$FRONTEND_PATH"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    xdg-open "$FRONTEND_PATH"
elif [[ "$OSTYPE" == "msys" || "$OSTYPE" == "cygwin" ]]; then
    # Windows
    start "$FRONTEND_PATH"
else
    echo "⚠️  Could not detect OS. Please open this file manually:"
    echo "   $FRONTEND_PATH"
fi

echo ""
echo "=========================================="
echo "✅ Frontend opened!"
echo "=========================================="
echo ""
echo "Backend API: http://localhost:5001"
echo "API Endpoints:"
echo "  - GET    /api/todos       (List all todos)"
echo "  - POST   /api/todos       (Create todo)"
echo "  - GET    /api/todos/:id   (Get single todo)"
echo "  - PUT    /api/todos/:id   (Update todo)"
echo "  - DELETE /api/todos/:id   (Delete todo)"
echo ""

# Made with Bob
