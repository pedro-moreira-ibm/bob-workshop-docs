# Todo Application - Implementation Guide

This guide provides code snippets and implementation details for each component of the todo application.

---

## 1. Backend Implementation

### File: `backend/app.py`

```python
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todos.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Enable CORS for all routes
CORS(app)

db = SQLAlchemy(app)

# Todo Model
class Todo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    completed = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'completed': self.completed,
            'created_at': self.created_at.isoformat()
        }

# Create tables
with app.app_context():
    db.create_all()

# Routes
@app.route('/api/todos', methods=['GET'])
def get_todos():
    todos = Todo.query.all()
    return jsonify([todo.to_dict() for todo in todos])

@app.route('/api/todos/<int:id>', methods=['GET'])
def get_todo(id):
    todo = Todo.query.get_or_404(id)
    return jsonify(todo.to_dict())

@app.route('/api/todos', methods=['POST'])
def create_todo():
    data = request.get_json()
    
    if not data or not data.get('title'):
        return jsonify({'error': 'Title is required'}), 400
    
    todo = Todo(
        title=data['title'],
        description=data.get('description', '')
    )
    
    db.session.add(todo)
    db.session.commit()
    
    return jsonify(todo.to_dict()), 201

@app.route('/api/todos/<int:id>', methods=['PUT'])
def update_todo(id):
    todo = Todo.query.get_or_404(id)
    data = request.get_json()
    
    if 'title' in data:
        todo.title = data['title']
    if 'description' in data:
        todo.description = data['description']
    if 'completed' in data:
        todo.completed = data['completed']
    
    db.session.commit()
    return jsonify(todo.to_dict())

@app.route('/api/todos/<int:id>', methods=['DELETE'])
def delete_todo(id):
    todo = Todo.query.get_or_404(id)
    db.session.delete(todo)
    db.session.commit()
    return jsonify({'message': 'Todo deleted successfully'})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
```

### File: `backend/requirements.txt`

```
Flask==3.0.0
Flask-CORS==4.0.0
Flask-SQLAlchemy==3.1.1
```

---

## 2. Frontend Implementation

### File: `frontend/index.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo Application</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>📝 My Todo List</h1>
        </header>

        <main>
            <!-- Add Todo Form -->
            <section class="add-todo-section">
                <form id="todoForm">
                    <div class="form-group">
                        <input 
                            type="text" 
                            id="todoTitle" 
                            placeholder="What needs to be done?" 
                            required
                            autocomplete="off"
                        >
                    </div>
                    <div class="form-group">
                        <textarea 
                            id="todoDescription" 
                            placeholder="Add a description (optional)"
                            rows="3"
                        ></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Todo</button>
                </form>
            </section>

            <!-- Todo List -->
            <section class="todos-section">
                <div id="loadingSpinner" class="loading hidden">Loading...</div>
                <div id="errorMessage" class="error-message hidden"></div>
                <div id="todoList" class="todo-list"></div>
                <div id="emptyState" class="empty-state hidden">
                    <p>No todos yet. Add one above to get started!</p>
                </div>
            </section>
        </main>

        <footer>
            <p>Built with Flask & JavaScript</p>
        </footer>
    </div>

    <script src="js/app.js"></script>
</body>
</html>
```

### File: `frontend/js/app.js`

```javascript
// API Configuration
const API_BASE_URL = 'http://localhost:5000/api';

// DOM Elements
const todoForm = document.getElementById('todoForm');
const todoTitle = document.getElementById('todoTitle');
const todoDescription = document.getElementById('todoDescription');
const todoList = document.getElementById('todoList');
const loadingSpinner = document.getElementById('loadingSpinner');
const errorMessage = document.getElementById('errorMessage');
const emptyState = document.getElementById('emptyState');

// State
let todos = [];
let editingTodoId = null;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    loadTodos();
    todoForm.addEventListener('submit', handleFormSubmit);
});

// API Functions
async function loadTodos() {
    try {
        showLoading(true);
        hideError();
        
        const response = await fetch(`${API_BASE_URL}/todos`);
        if (!response.ok) throw new Error('Failed to fetch todos');
        
        todos = await response.json();
        renderTodos();
    } catch (error) {
        showError('Failed to load todos. Please try again.');
        console.error('Error loading todos:', error);
    } finally {
        showLoading(false);
    }
}

async function createTodo(title, description) {
    try {
        const response = await fetch(`${API_BASE_URL}/todos`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title, description }),
        });
        
        if (!response.ok) throw new Error('Failed to create todo');
        
        const newTodo = await response.json();
        todos.push(newTodo);
        renderTodos();
        return newTodo;
    } catch (error) {
        showError('Failed to create todo. Please try again.');
        console.error('Error creating todo:', error);
        throw error;
    }
}

async function updateTodo(id, updates) {
    try {
        const response = await fetch(`${API_BASE_URL}/todos/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updates),
        });
        
        if (!response.ok) throw new Error('Failed to update todo');
        
        const updatedTodo = await response.json();
        todos = todos.map(todo => todo.id === id ? updatedTodo : todo);
        renderTodos();
        return updatedTodo;
    } catch (error) {
        showError('Failed to update todo. Please try again.');
        console.error('Error updating todo:', error);
        throw error;
    }
}

async function deleteTodo(id) {
    try {
        const response = await fetch(`${API_BASE_URL}/todos/${id}`, {
            method: 'DELETE',
        });
        
        if (!response.ok) throw new Error('Failed to delete todo');
        
        todos = todos.filter(todo => todo.id !== id);
        renderTodos();
    } catch (error) {
        showError('Failed to delete todo. Please try again.');
        console.error('Error deleting todo:', error);
        throw error;
    }
}

// Event Handlers
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const title = todoTitle.value.trim();
    const description = todoDescription.value.trim();
    
    if (!title) return;
    
    try {
        if (editingTodoId) {
            await updateTodo(editingTodoId, { title, description });
            editingTodoId = null;
            todoForm.querySelector('button[type="submit"]').textContent = 'Add Todo';
        } else {
            await createTodo(title, description);
        }
        
        todoForm.reset();
        hideError();
    } catch (error) {
        // Error already handled in API functions
    }
}

function handleToggleComplete(id) {
    const todo = todos.find(t => t.id === id);
    if (todo) {
        updateTodo(id, { completed: !todo.completed });
    }
}

function handleEdit(id) {
    const todo = todos.find(t => t.id === id);
    if (todo) {
        todoTitle.value = todo.title;
        todoDescription.value = todo.description || '';
        editingTodoId = id;
        todoForm.querySelector('button[type="submit"]').textContent = 'Update Todo';
        todoTitle.focus();
    }
}

function handleDelete(id) {
    if (confirm('Are you sure you want to delete this todo?')) {
        deleteTodo(id);
    }
}

// Render Functions
function renderTodos() {
    if (todos.length === 0) {
        todoList.innerHTML = '';
        emptyState.classList.remove('hidden');
        return;
    }
    
    emptyState.classList.add('hidden');
    
    todoList.innerHTML = todos.map(todo => `
        <div class="todo-item ${todo.completed ? 'completed' : ''}" data-id="${todo.id}">
            <div class="todo-content">
                <input 
                    type="checkbox" 
                    ${todo.completed ? 'checked' : ''} 
                    onchange="handleToggleComplete(${todo.id})"
                    class="todo-checkbox"
                >
                <div class="todo-text">
                    <h3 class="todo-title">${escapeHtml(todo.title)}</h3>
                    ${todo.description ? `<p class="todo-description">${escapeHtml(todo.description)}</p>` : ''}
                    <span class="todo-date">${formatDate(todo.created_at)}</span>
                </div>
            </div>
            <div class="todo-actions">
                <button onclick="handleEdit(${todo.id})" class="btn btn-edit" title="Edit">✏️</button>
                <button onclick="handleDelete(${todo.id})" class="btn btn-delete" title="Delete">🗑️</button>
            </div>
        </div>
    `).join('');
}

// Utility Functions
function showLoading(show) {
    loadingSpinner.classList.toggle('hidden', !show);
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.remove('hidden');
}

function hideError() {
    errorMessage.classList.add('hidden');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}
```

### File: `frontend/css/styles.css`

```css
/* Reset and Base Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 20px;
    color: #333;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    background: white;
    border-radius: 20px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    overflow: hidden;
}

/* Header */
header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    text-align: center;
}

header h1 {
    font-size: 2.5rem;
    font-weight: 700;
}

/* Main Content */
main {
    padding: 30px;
}

/* Add Todo Section */
.add-todo-section {
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 15px;
}

input[type="text"],
textarea {
    width: 100%;
    padding: 15px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    transition: border-color 0.3s;
    font-family: inherit;
}

input[type="text"]:focus,
textarea:focus {
    outline: none;
    border-color: #667eea;
}

textarea {
    resize: vertical;
}

/* Buttons */
.btn {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s;
    font-weight: 600;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    width: 100%;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

.btn-edit,
.btn-delete {
    background: none;
    border: none;
    font-size: 1.2rem;
    cursor: pointer;
    padding: 5px 10px;
    transition: transform 0.2s;
}

.btn-edit:hover,
.btn-delete:hover {
    transform: scale(1.2);
}

/* Todo List */
.todos-section {
    min-height: 200px;
}

.todo-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.todo-item {
    background: #f8f9fa;
    border-radius: 12px;
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    transition: all 0.3s;
    border: 2px solid transparent;
}

.todo-item:hover {
    border-color: #667eea;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.todo-item.completed {
    opacity: 0.6;
}

.todo-item.completed .todo-title {
    text-decoration: line-through;
}

.todo-content {
    display: flex;
    gap: 15px;
    flex: 1;
}

.todo-checkbox {
    width: 24px;
    height: 24px;
    cursor: pointer;
    margin-top: 2px;
}

.todo-text {
    flex: 1;
}

.todo-title {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 5px;
    color: #333;
}

.todo-description {
    color: #666;
    margin-bottom: 8px;
    line-height: 1.5;
}

.todo-date {
    font-size: 0.85rem;
    color: #999;
}

.todo-actions {
    display: flex;
    gap: 5px;
}

/* Loading and Error States */
.loading,
.error-message,
.empty-state {
    text-align: center;
    padding: 40px;
    color: #666;
}

.error-message {
    background: #fee;
    color: #c33;
    border-radius: 8px;
    margin-bottom: 20px;
}

.hidden {
    display: none;
}

/* Footer */
footer {
    background: #f8f9fa;
    padding: 20px;
    text-align: center;
    color: #666;
    font-size: 0.9rem;
}

/* Responsive Design */
@media (max-width: 600px) {
    body {
        padding: 10px;
    }
    
    header h1 {
        font-size: 2rem;
    }
    
    main {
        padding: 20px;
    }
    
    .todo-item {
        flex-direction: column;
        gap: 15px;
    }
    
    .todo-actions {
        width: 100%;
        justify-content: flex-end;
    }
}
```

---

## 3. Configuration Files

### File: `.gitignore`

```
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/
ENV/
instance/
*.db

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log
```

---

## 4. Setup Instructions

### Backend Setup

```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the Flask server
python app.py
```

The backend will run on `http://localhost:5000`

### Frontend Setup

Option 1: Open directly in browser
```bash
# Simply open frontend/index.html in your browser
open frontend/index.html  # macOS
start frontend/index.html # Windows
```

Option 2: Use Python's built-in server
```bash
# Navigate to frontend directory
cd frontend

# Start server
python -m http.server 8000

# Open browser to http://localhost:8000
```

---

## 5. Testing the Application

### Manual Testing Checklist

- [ ] Backend server starts without errors
- [ ] Frontend loads in browser
- [ ] Can create a new todo
- [ ] New todo appears in the list
- [ ] Can mark todo as complete
- [ ] Can edit an existing todo
- [ ] Can delete a todo
- [ ] Empty state shows when no todos
- [ ] Error messages display on failures
- [ ] Data persists after page refresh

### Testing with curl

```bash
# Get all todos
curl http://localhost:5000/api/todos

# Create a todo
curl -X POST http://localhost:5000/api/todos \
  -H "Content-Type: application/json" \
  -d '{"title":"Test Todo","description":"Testing the API"}'

# Update a todo
curl -X PUT http://localhost:5000/api/todos/1 \
  -H "Content-Type: application/json" \
  -d '{"completed":true}'

# Delete a todo
curl -X DELETE http://localhost:5000/api/todos/1
```

---

## 6. Common Issues and Solutions

### Issue: CORS errors in browser console
**Solution:** Ensure Flask-CORS is installed and CORS(app) is called in app.py

### Issue: Database not found
**Solution:** The database is created automatically. Ensure the instance folder exists or let Flask create it.

### Issue: Port already in use
**Solution:** Change the port in app.py: `app.run(debug=True, port=5001)`

### Issue: Frontend can't connect to backend
**Solution:** Verify the API_BASE_URL in app.js matches your Flask server address

---

## 7. Next Steps After Implementation

1. Test all functionality thoroughly
2. Add input validation and error handling
3. Consider adding features like:
   - Search/filter todos
   - Sort by date or status
   - Categories or tags
   - Due dates
   - Priority levels
4. Deploy to production (Heroku, PythonAnywhere, etc.)
5. Add user authentication for multi-user support

---

## 8. Code Quality Checklist

- [ ] Code is properly indented and formatted
- [ ] Variables have meaningful names
- [ ] Functions are small and focused
- [ ] Error handling is implemented
- [ ] Comments explain complex logic
- [ ] No hardcoded values (use constants)
- [ ] Code follows Python PEP 8 style guide
- [ ] JavaScript follows ES6+ best practices