# 📝 Todo Application

A full-stack todo application built with **Python Flask** backend and **vanilla JavaScript** frontend.

![Status](https://img.shields.io/badge/status-active-success.svg)
![Python](https://img.shields.io/badge/python-3.8+-blue.svg)
![Flask](https://img.shields.io/badge/flask-3.0-green.svg)
![JavaScript](https://img.shields.io/badge/javascript-ES6+-yellow.svg)

## 🌟 Features

### Backend (Flask)
- ✅ RESTful API with 5 endpoints
- ✅ SQLite database with SQLAlchemy ORM
- ✅ CORS enabled for frontend communication
- ✅ Comprehensive error handling
- ✅ Input validation
- ✅ 98% test coverage with pytest
- ✅ Automatic database initialization

### Frontend (Vanilla JS)
- ✅ Modern, responsive UI design
- ✅ Real-time statistics dashboard
- ✅ Filter todos (All/Active/Completed)
- ✅ Edit modal for updating todos
- ✅ Smooth animations and transitions
- ✅ Mobile-friendly responsive design
- ✅ Keyboard shortcuts
- ✅ Relative timestamps
- ✅ Error handling with auto-dismiss

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)
- Modern web browser

### 1. Clone or Download the Project

```bash
cd todo-app
```

### 2. Start the Backend

```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate  # macOS/Linux
# or
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Start the server
python app.py
```

Backend will be running at: **http://localhost:5001**

### 3. Open the Frontend

**Option A: Direct open (simplest)**
```bash
open frontend/index.html  # macOS
start frontend/index.html # Windows
```

**Option B: Python HTTP Server (recommended)**
```bash
# In a new terminal
cd frontend
python3 -m http.server 8000
```
Then open: **http://localhost:8000**

## 📁 Project Structure

```
todo-app/
├── backend/                      # Flask backend
│   ├── app.py                   # Main Flask application
│   ├── models.py                # Database models
│   ├── database.py              # Database configuration
│   ├── requirements.txt         # Python dependencies
│   ├── test_app.py              # Unit tests
│   ├── pytest.ini               # Pytest configuration
│   ├── .coveragerc              # Coverage configuration
│   ├── start_server.sh          # Server startup script (Unix)
│   ├── start_server.bat         # Server startup script (Windows)
│   ├── run_tests.sh             # Test runner script (Unix)
│   ├── run_tests.bat            # Test runner script (Windows)
│   ├── test_api_endpoints.sh    # API testing script
│   ├── SETUP.md                 # Backend setup guide
│   ├── TESTING.md               # Testing documentation
│   ├── TEST_SUMMARY.md          # Test coverage summary
│   └── API_TEST_RESULTS.md      # API test results
│
├── frontend/                     # JavaScript frontend
│   ├── index.html               # Main HTML file
│   ├── css/
│   │   └── styles.css           # Application styles
│   ├── js/
│   │   └── app.js               # Frontend logic
│   └── README.md                # Frontend documentation
│
├── PROJECT_PLAN.md              # Detailed project planning
├── ARCHITECTURE.md              # System architecture diagrams
├── IMPLEMENTATION_GUIDE.md      # Implementation details
└── README.md                    # This file
```

## 🔌 API Endpoints

| Method | Endpoint | Description | Request Body |
|--------|----------|-------------|--------------|
| GET | `/api/health` | Health check | None |
| GET | `/api/todos` | Get all todos | None |
| GET | `/api/todos/<id>` | Get single todo | None |
| POST | `/api/todos` | Create new todo | `{title, description?}` |
| PUT | `/api/todos/<id>` | Update todo | `{title?, description?, completed?}` |
| DELETE | `/api/todos/<id>` | Delete todo | None |

### Example API Calls

```bash
# Health check
curl http://localhost:5001/api/health

# Get all todos
curl http://localhost:5001/api/todos

# Create a todo
curl -X POST http://localhost:5001/api/todos \
  -H "Content-Type: application/json" \
  -d '{"title":"Learn Flask","description":"Build a REST API"}'

# Update a todo
curl -X PUT http://localhost:5001/api/todos/1 \
  -H "Content-Type: application/json" \
  -d '{"completed":true}'

# Delete a todo
curl -X DELETE http://localhost:5001/api/todos/1
```

## 🧪 Testing

### Run Backend Tests

```bash
cd backend

# Using test script
./run_tests.sh  # Unix/Linux
run_tests.bat   # Windows

# Or using pytest directly
pytest --cov=. --cov-report=term-missing --cov-report=html
```

### Test Coverage
- **Total Coverage**: 98%
- **Total Tests**: 35+
- **All tests passing**: ✅

View detailed coverage report:
```bash
open backend/htmlcov/index.html  # macOS
start backend/htmlcov/index.html # Windows
```

### Test API Endpoints

```bash
cd backend
./test_api_endpoints.sh
```

## 💻 Technology Stack

### Backend
- **Python 3.13** - Programming language
- **Flask 3.0** - Web framework
- **Flask-CORS 4.0** - Cross-origin support
- **Flask-SQLAlchemy 3.1** - Database ORM
- **SQLite** - Database
- **pytest 7.4** - Testing framework
- **pytest-cov 4.1** - Coverage plugin

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with variables
- **JavaScript ES6+** - Vanilla JavaScript
- **Fetch API** - HTTP requests

## 🎨 Features Showcase

### Todo Management
- ✅ Create todos with title and optional description
- ✅ Mark todos as complete/incomplete with checkbox
- ✅ Edit todos in a modal dialog
- ✅ Delete todos with confirmation
- ✅ View all todos with newest first

### User Interface
- 📊 Real-time statistics (Total, Active, Completed)
- 🔍 Filter by All, Active, or Completed
- 📱 Fully responsive design
- ⌨️ Keyboard shortcuts (Ctrl/Cmd + K)
- ⏰ Relative timestamps ("2 hours ago")
- 🎭 Smooth animations and transitions
- 🎨 Modern gradient design

### Developer Experience
- 📝 Comprehensive documentation
- 🧪 98% test coverage
- 🔧 Easy setup and configuration
- 📊 Detailed API testing
- 🚀 Quick start scripts

## 🛠️ Configuration

### Backend Port
Default: `5001` (changed from 5000 due to macOS AirPlay conflict)

To change, edit `backend/app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

### Frontend API URL
Default: `http://localhost:5001/api`

To change, edit `frontend/js/app.js`:
```javascript
const API_BASE_URL = 'http://localhost:5001/api';
```

## 📚 Documentation

- **[PROJECT_PLAN.md](PROJECT_PLAN.md)** - Comprehensive project planning
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System architecture with diagrams
- **[IMPLEMENTATION_GUIDE.md](IMPLEMENTATION_GUIDE.md)** - Code snippets and setup
- **[backend/SETUP.md](backend/SETUP.md)** - Backend setup guide
- **[backend/TESTING.md](backend/TESTING.md)** - Testing documentation
- **[backend/API_TEST_RESULTS.md](backend/API_TEST_RESULTS.md)** - API test results
- **[frontend/README.md](frontend/README.md)** - Frontend documentation

## 🐛 Troubleshooting

### Backend Issues

**Port 5000 already in use:**
- macOS: Disable AirPlay Receiver in System Settings
- Or: Change port in `app.py` to 5001 (already done)

**Module not found errors:**
```bash
cd backend
source venv/bin/activate
pip install -r requirements.txt
```

**Database errors:**
- Delete `backend/todos.db` and restart
- Database will be recreated automatically

### Frontend Issues

**Todos not loading:**
- Ensure backend is running on port 5001
- Check browser console for errors
- Verify API_BASE_URL in `app.js`

**CORS errors:**
- Ensure Flask-CORS is installed
- Backend must be running

## 🚀 Deployment

### Backend Deployment Options
- **Heroku**: Use Procfile and requirements.txt
- **PythonAnywhere**: Upload files and configure WSGI
- **AWS EC2**: Deploy with Gunicorn and Nginx
- **Docker**: Create Dockerfile for containerization

### Frontend Deployment Options
- **GitHub Pages**: Static hosting
- **Netlify**: Automatic deployment from Git
- **Vercel**: Zero-config deployment
- **AWS S3**: Static website hosting

## 🔮 Future Enhancements

- [ ] User authentication and authorization
- [ ] Multiple users support
- [ ] Categories and tags
- [ ] Due dates with reminders
- [ ] Priority levels
- [ ] Search functionality
- [ ] Drag and drop reordering
- [ ] Dark mode toggle
- [ ] Export/import todos
- [ ] Real-time collaboration
- [ ] Mobile app (React Native)
- [ ] Email notifications
- [ ] Recurring todos

## 📄 License

This project is open source and available for educational purposes.

## 🤝 Contributing

This is a learning project. Feel free to fork and modify for your own use!

## 👨‍💻 Author

Built with ❤️ using Flask and JavaScript

## 🙏 Acknowledgments

- Flask documentation
- MDN Web Docs
- Python community
- Open source contributors

---

**Happy Todo-ing! 📝✨**

For questions or issues, please refer to the documentation files in this repository.