# Frontend - Todo Application

A modern, responsive frontend for the Todo application built with vanilla JavaScript, HTML5, and CSS3.

## Features

✨ **Modern UI/UX**
- Clean, gradient-based design
- Smooth animations and transitions
- Responsive layout for mobile and desktop
- Dark mode ready (can be extended)

📊 **Statistics Dashboard**
- Real-time todo counts
- Active vs completed tracking
- Visual stat cards

🔍 **Filtering**
- View all todos
- Filter by active todos
- Filter by completed todos

✏️ **Full CRUD Operations**
- Create todos with title and description
- Edit existing todos in modal
- Mark todos as complete/incomplete
- Delete todos with confirmation

⚡ **User Experience**
- Loading states
- Error handling with auto-dismiss
- Empty state messaging
- Keyboard shortcuts (Ctrl/Cmd + K to focus input)
- Relative timestamps (e.g., "2 hours ago")

## File Structure

```
frontend/
├── index.html          # Main HTML structure
├── css/
│   └── styles.css      # All styling and responsive design
├── js/
│   └── app.js          # JavaScript logic and API calls
└── README.md           # This file
```

## Setup & Usage

### Option 1: Open Directly in Browser

Simply open `index.html` in your web browser:

```bash
# macOS
open frontend/index.html

# Windows
start frontend/index.html

# Linux
xdg-open frontend/index.html
```

### Option 2: Use Python HTTP Server (Recommended)

```bash
cd frontend
python3 -m http.server 8000
```

Then open: http://localhost:8000

### Option 3: Use Live Server (VS Code Extension)

1. Install "Live Server" extension in VS Code
2. Right-click on `index.html`
3. Select "Open with Live Server"

## Configuration

### API Endpoint

The frontend connects to the backend API at `http://localhost:5001/api` by default.

To change this, edit `js/app.js`:

```javascript
const API_BASE_URL = 'http://localhost:5001/api';
```

## Features Breakdown

### 1. Add Todo Form
- Title input (required, max 200 characters)
- Description textarea (optional, max 500 characters)
- Submit button with icon

### 2. Statistics Cards
- **Total**: All todos count
- **Active**: Incomplete todos count
- **Completed**: Completed todos count

### 3. Filter Buttons
- **All**: Show all todos
- **Active**: Show only incomplete todos
- **Completed**: Show only completed todos

### 4. Todo List
Each todo item displays:
- Checkbox to toggle completion
- Title (with strikethrough when completed)
- Description (if provided)
- Relative timestamp
- Edit button (opens modal)
- Delete button (with confirmation)

### 5. Edit Modal
- Full-screen overlay
- Form to edit title and description
- Save and Cancel buttons
- Close on Escape key or outside click

## Keyboard Shortcuts

- `Ctrl/Cmd + K`: Focus on todo input field
- `Escape`: Close edit modal

## Responsive Design

The application is fully responsive with breakpoints at:
- **Desktop**: > 768px (full layout)
- **Tablet**: 768px (adjusted stats layout)
- **Mobile**: < 480px (stacked layout)

### Mobile Optimizations
- Single column stats
- Stacked todo items
- Full-width buttons
- Touch-friendly tap targets

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Styling Details

### Color Palette
- **Primary**: Purple gradient (#667eea to #764ba2)
- **Success**: Green (#48bb78)
- **Danger**: Red (#f56565)
- **Neutral**: Gray scale

### Animations
- Fade in on page load
- Slide in for new todos
- Bounce effect on checkmark
- Heartbeat on footer heart icon
- Smooth transitions on hover

## API Integration

The frontend communicates with the Flask backend using the Fetch API:

### Endpoints Used
- `GET /api/todos` - Load all todos
- `POST /api/todos` - Create new todo
- `PUT /api/todos/:id` - Update todo
- `DELETE /api/todos/:id` - Delete todo

### Error Handling
- Network errors display user-friendly messages
- Auto-dismiss after 5 seconds
- Console logging for debugging

## Development

### Adding New Features

1. **Add HTML structure** in `index.html`
2. **Add styles** in `css/styles.css`
3. **Add JavaScript logic** in `js/app.js`

### Code Organization

**app.js** is organized into sections:
- Configuration
- DOM Elements
- State Management
- Event Listeners
- API Functions
- Event Handlers
- Render Functions
- UI Helpers
- Utility Functions

## Performance Optimizations

- Minimal DOM manipulation
- Event delegation where possible
- Debounced API calls (can be added)
- Lazy loading (can be added)
- Service Worker ready (commented out)

## Accessibility

- Semantic HTML5 elements
- ARIA labels on interactive elements
- Keyboard navigation support
- Focus management in modal
- Color contrast compliance

## Future Enhancements

Potential features to add:
- [ ] Dark mode toggle
- [ ] Drag and drop reordering
- [ ] Due dates with calendar picker
- [ ] Priority levels with color coding
- [ ] Search functionality
- [ ] Bulk actions (delete all completed)
- [ ] Export/import todos
- [ ] Offline support with Service Worker
- [ ] Local storage backup
- [ ] Undo/redo functionality

## Troubleshooting

### Todos not loading
- Ensure backend server is running on port 5001
- Check browser console for errors
- Verify API_BASE_URL in app.js

### CORS errors
- Backend must have Flask-CORS enabled
- Check backend is running on correct port

### Styling issues
- Clear browser cache
- Check styles.css is loading
- Verify file paths are correct

## Credits

Built with:
- Vanilla JavaScript (ES6+)
- CSS3 with CSS Variables
- HTML5 Semantic Elements
- Fetch API for HTTP requests

No frameworks or libraries required! 🎉