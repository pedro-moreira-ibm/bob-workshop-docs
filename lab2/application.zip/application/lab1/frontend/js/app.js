/*
 * ===================================
 * TODO APPLICATION - FRONTEND JAVASCRIPT
 * ===================================
 * 
 * This file contains all the JavaScript logic for the Todo application.
 * It handles communication with the Flask backend API and manages the user interface.
 * 
 * LEARNING OBJECTIVES:
 * - Understand how to make API calls with the Fetch API
 * - Learn about async/await for handling asynchronous operations
 * - See how to manipulate the DOM (Document Object Model)
 * - Understand error handling in JavaScript
 * - Learn about state management in vanilla JavaScript
 */

// ===================================
// CONFIGURATION
// ===================================

/*
 * API_BASE_URL: The base URL for our Flask backend API
 * 
 * WHY: We store this in a constant so we can easily change it if needed
 * (e.g., when deploying to production with a different URL)
 * 
 * NOTE: Port 5001 is used instead of 5000 because macOS uses port 5000
 * for AirPlay Receiver by default
 */
const API_BASE_URL = 'http://localhost:5001/api';

// ===================================
// DOM ELEMENTS
// ===================================

/*
 * DOM (Document Object Model) Elements
 * 
 * WHY: We cache references to HTML elements at the start for better performance.
 * Instead of searching the DOM every time we need an element, we store the
 * reference once and reuse it.
 * 
 * WHAT: document.getElementById() finds an HTML element by its 'id' attribute
 * and returns a reference to that element that we can manipulate with JavaScript
 */

// Form elements - used for creating new todos
const todoForm = document.getElementById('todoForm');
const todoTitle = document.getElementById('todoTitle');
const todoDescription = document.getElementById('todoDescription');

// Display elements - where todos are shown
const todoList = document.getElementById('todoList');
const loadingSpinner = document.getElementById('loadingSpinner');
const errorMessage = document.getElementById('errorMessage');
const errorText = document.getElementById('errorText');
const emptyState = document.getElementById('emptyState');

// Statistics elements - show counts of todos
const totalCount = document.getElementById('totalCount');
const activeCount = document.getElementById('activeCount');
const completedCount = document.getElementById('completedCount');

// Filter buttons - for filtering todos by status
const filterButtons = document.querySelectorAll('.filter-btn');

// Modal elements - for editing todos
const editModal = document.getElementById('editModal');
const editForm = document.getElementById('editForm');
const editTitle = document.getElementById('editTitle');
const editDescription = document.getElementById('editDescription');
const closeModal = document.getElementById('closeModal');
const cancelEdit = document.getElementById('cancelEdit');

// ===================================
// STATE MANAGEMENT
// ===================================

/*
 * Application State
 * 
 * WHY: We need to keep track of data that changes over time.
 * This is called "state" in programming.
 * 
 * WHAT:
 * - todos: Array that stores all our todo items
 * - currentFilter: String that tracks which filter is active ('all', 'active', or 'completed')
 * - editingTodoId: Number that stores the ID of the todo being edited (null when not editing)
 */
let todos = [];
let currentFilter = 'all';
let editingTodoId = null;

// ===================================
// INITIALIZE APPLICATION
// ===================================

/*
 * DOMContentLoaded Event
 * 
 * WHY: We wait for the HTML to fully load before running our JavaScript.
 * If we try to access HTML elements before they exist, we'll get errors.
 * 
 * HOW: The browser fires the 'DOMContentLoaded' event when the HTML is ready.
 * We listen for this event and then initialize our app.
 */
document.addEventListener('DOMContentLoaded', () => {
    // Load todos from the backend when the page loads
    loadTodos();
    
    // Set up all event listeners (button clicks, form submissions, etc.)
    setupEventListeners();
});

// ===================================
// EVENT LISTENERS SETUP
// ===================================

/*
 * setupEventListeners()
 * 
 * PURPOSE: Attach event listeners to interactive elements
 * 
 * WHY: Event listeners "listen" for user actions (clicks, key presses, etc.)
 * and run functions when those actions occur.
 * 
 * WHAT: We set up listeners for:
 * - Form submission (creating todos)
 * - Filter button clicks
 * - Modal open/close actions
 * - Keyboard shortcuts
 */
function setupEventListeners() {
    // Listen for form submission (when user clicks "Add Todo" button)
    // preventDefault() stops the form from refreshing the page
    todoForm.addEventListener('submit', handleFormSubmit);
    
    // Listen for clicks on filter buttons (All, Active, Completed)
    filterButtons.forEach(btn => {
        btn.addEventListener('click', handleFilterChange);
    });
    
    // Modal event listeners
    closeModal.addEventListener('click', hideModal);
    cancelEdit.addEventListener('click', hideModal);
    editForm.addEventListener('submit', handleEditSubmit);
    
    // Close modal when clicking outside of it
    editModal.addEventListener('click', (e) => {
        if (e.target === editModal) {
            hideModal();
        }
    });
    
    // Close modal when pressing Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !editModal.classList.contains('hidden')) {
            hideModal();
        }
    });
}

// ===================================
// API FUNCTIONS
// ===================================

/*
 * ABOUT ASYNC/AWAIT:
 * 
 * WHY: API calls take time (network requests aren't instant).
 * We use async/await to handle these "asynchronous" operations.
 * 
 * HOW IT WORKS:
 * 1. 'async' keyword: Marks a function as asynchronous
 * 2. 'await' keyword: Pauses execution until a Promise resolves
 * 3. This makes asynchronous code look and behave like synchronous code
 * 
 * EXAMPLE:
 * Without async/await:
 *   fetch(url).then(response => response.json()).then(data => console.log(data))
 * 
 * With async/await:
 *   const response = await fetch(url);
 *   const data = await response.json();
 *   console.log(data);
 * 
 * Much cleaner and easier to read!
 */

/*
 * loadTodos()
 * 
 * PURPOSE: Fetch all todos from the backend API
 * 
 * HOW IT WORKS:
 * 1. Show loading spinner to user
 * 2. Make GET request to /api/todos endpoint
 * 3. Convert response to JSON
 * 4. Store todos in our state
 * 5. Update the UI to display the todos
 * 6. Hide loading spinner
 * 
 * ERROR HANDLING:
 * - try/catch block catches any errors that occur
 * - If an error happens, we show a user-friendly message
 * - finally block runs regardless of success/failure (to hide spinner)
 */
async function loadTodos() {
    try {
        // Show loading indicator to user
        showLoading(true);
        hideError();
        
        /*
         * FETCH API:
         * fetch() is a modern way to make HTTP requests in JavaScript
         * It returns a Promise that resolves to a Response object
         * 
         * WHY AWAIT: We wait for the network request to complete
         * before continuing to the next line
         */
        const response = await fetch(`${API_BASE_URL}/todos`);
        
        /*
         * ERROR CHECKING:
         * response.ok is true if status code is 200-299
         * If not ok, we throw an error to jump to the catch block
         */
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        /*
         * PARSING JSON:
         * response.json() converts the JSON string from the server
         * into a JavaScript array/object we can work with
         * 
         * WHY AWAIT: Parsing JSON is also asynchronous
         */
        todos = await response.json();
        
        // Update the UI with the loaded todos
        renderTodos();
        updateStats();
        
    } catch (error) {
        /*
         * ERROR HANDLING:
         * If anything goes wrong (network error, server error, etc.),
         * we catch it here and show a user-friendly message
         */
        console.error('Error loading todos:', error);
        showError('Failed to load todos. Please make sure the backend server is running on port 5001.');
    } finally {
        /*
         * FINALLY BLOCK:
         * This code runs whether the try block succeeds or fails
         * Perfect for cleanup tasks like hiding the loading spinner
         */
        showLoading(false);
    }
}

/*
 * createTodo()
 * 
 * PURPOSE: Send a new todo to the backend API
 * 
 * HOW IT WORKS:
 * 1. Make POST request with todo data in JSON format
 * 2. Backend creates the todo in the database
 * 3. Backend returns the created todo (with ID and timestamp)
 * 4. We add it to our local todos array
 * 5. Update the UI
 * 
 * HTTP METHOD: POST is used for creating new resources
 * 
 * PARAMETERS:
 * @param {string} title - The todo title (required)
 * @param {string} description - The todo description (optional)
 * @returns {Promise<Object>} The created todo object
 */
async function createTodo(title, description) {
    try {
        /*
         * FETCH WITH OPTIONS:
         * When making POST/PUT/DELETE requests, we need to specify:
         * - method: The HTTP method to use
         * - headers: Metadata about the request (we're sending JSON)
         * - body: The actual data to send (must be a JSON string)
         */
        const response = await fetch(`${API_BASE_URL}/todos`, {
            method: 'POST',  // POST = create new resource
            headers: {
                'Content-Type': 'application/json',  // Tell server we're sending JSON
            },
            body: JSON.stringify({ title, description }),  // Convert object to JSON string
        });
        
        // Check if request was successful
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to create todo');
        }
        
        // Get the created todo from the response
        const newTodo = await response.json();
        
        /*
         * UPDATE LOCAL STATE:
         * unshift() adds the new todo to the beginning of the array
         * (newest todos appear first)
         */
        todos.unshift(newTodo);
        
        // Update the UI to show the new todo
        renderTodos();
        updateStats();
        
        return newTodo;
        
    } catch (error) {
        // Show error message to user
        console.error('Error creating todo:', error);
        showError(error.message);
        throw error;  // Re-throw so calling function knows it failed
    }
}

/*
 * updateTodo()
 * 
 * PURPOSE: Update an existing todo on the backend
 * 
 * HOW IT WORKS:
 * 1. Make PUT request with updated data
 * 2. Backend updates the todo in the database
 * 3. Backend returns the updated todo
 * 4. We update our local todos array
 * 5. Re-render the UI
 * 
 * HTTP METHOD: PUT is used for updating existing resources
 * 
 * PARAMETERS:
 * @param {number} id - The ID of the todo to update
 * @param {Object} updates - Object containing fields to update
 * @returns {Promise<Object>} The updated todo object
 */
async function updateTodo(id, updates) {
    try {
        const response = await fetch(`${API_BASE_URL}/todos/${id}`, {
            method: 'PUT',  // PUT = update existing resource
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updates),
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to update todo');
        }
        
        const updatedTodo = await response.json();
        
        /*
         * UPDATE LOCAL STATE:
         * map() creates a new array by transforming each element
         * We replace the old todo with the updated one
         */
        todos = todos.map(todo => todo.id === id ? updatedTodo : todo);
        
        renderTodos();
        updateStats();
        
        return updatedTodo;
        
    } catch (error) {
        console.error('Error updating todo:', error);
        showError(error.message);
        throw error;
    }
}

/*
 * deleteTodo()
 * 
 * PURPOSE: Delete a todo from the backend
 * 
 * HOW IT WORKS:
 * 1. Make DELETE request to backend
 * 2. Backend removes todo from database
 * 3. We remove it from our local todos array
 * 4. Re-render the UI
 * 
 * HTTP METHOD: DELETE is used for removing resources
 * 
 * PARAMETERS:
 * @param {number} id - The ID of the todo to delete
 */
async function deleteTodo(id) {
    try {
        const response = await fetch(`${API_BASE_URL}/todos/${id}`, {
            method: 'DELETE',  // DELETE = remove resource
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to delete todo');
        }
        
        /*
         * UPDATE LOCAL STATE:
         * filter() creates a new array with only items that pass the test
         * We keep all todos except the one with the matching ID
         */
        todos = todos.filter(todo => todo.id !== id);
        
        renderTodos();
        updateStats();
        
    } catch (error) {
        console.error('Error deleting todo:', error);
        showError(error.message);
        throw error;
    }
}

// ===================================
// EVENT HANDLERS
// ===================================

/*
 * EVENT HANDLERS:
 * These functions are called when user interactions occur
 * They process the user's action and update the application accordingly
 */

/*
 * handleFormSubmit()
 * 
 * PURPOSE: Handle the "Add Todo" form submission
 * 
 * PARAMETERS:
 * @param {Event} e - The form submit event object
 */
async function handleFormSubmit(e) {
    /*
     * PREVENT DEFAULT:
     * By default, form submission refreshes the page
     * preventDefault() stops this so we can handle it with JavaScript
     */
    e.preventDefault();
    
    // Get values from form inputs and remove extra whitespace
    const title = todoTitle.value.trim();
    const description = todoDescription.value.trim();
    
    // Validate that title is not empty
    if (!title) {
        showError('Please enter a todo title');
        return;
    }
    
    try {
        // Create the todo via API
        await createTodo(title, description);
        
        // Clear the form for next input
        todoForm.reset();
        
        // Put cursor back in title field for easy next entry
        todoTitle.focus();
        
        // Hide any previous error messages
        hideError();
    } catch (error) {
        // Error already handled in createTodo
    }
}

/*
 * handleFilterChange()
 * 
 * PURPOSE: Handle filter button clicks (All/Active/Completed)
 * 
 * PARAMETERS:
 * @param {Event} e - The click event object
 */
function handleFilterChange(e) {
    // Get the filter value from the button's data attribute
    const filter = e.target.dataset.filter;
    currentFilter = filter;
    
    // Update button styles to show which is active
    filterButtons.forEach(btn => btn.classList.remove('active'));
    e.target.classList.add('active');
    
    // Re-render todos with new filter
    renderTodos();
}

/*
 * handleToggleComplete()
 * 
 * PURPOSE: Toggle a todo's completed status
 * 
 * PARAMETERS:
 * @param {number} id - The ID of the todo to toggle
 */
async function handleToggleComplete(id) {
    // Find the todo in our array
    const todo = todos.find(t => t.id === id);
    if (todo) {
        // Update with opposite of current completed status
        await updateTodo(id, { completed: !todo.completed });
    }
}

/*
 * handleEdit()
 * 
 * PURPOSE: Open the edit modal with todo's current data
 * 
 * PARAMETERS:
 * @param {number} id - The ID of the todo to edit
 */
function handleEdit(id) {
    const todo = todos.find(t => t.id === id);
    if (todo) {
        // Store which todo we're editing
        editingTodoId = id;
        
        // Populate modal form with current values
        editTitle.value = todo.title;
        editDescription.value = todo.description || '';
        
        // Show the modal
        showModal();
    }
}

/*
 * handleEditSubmit()
 * 
 * PURPOSE: Handle the edit form submission
 * 
 * PARAMETERS:
 * @param {Event} e - The form submit event object
 */
async function handleEditSubmit(e) {
    e.preventDefault();
    
    const title = editTitle.value.trim();
    const description = editDescription.value.trim();
    
    if (!title) {
        showError('Please enter a todo title');
        return;
    }
    
    try {
        // Update the todo via API
        await updateTodo(editingTodoId, { title, description });
        
        // Close modal and reset
        hideModal();
        editingTodoId = null;
        hideError();
    } catch (error) {
        // Error already handled in updateTodo
    }
}

/*
 * handleDelete()
 *
 * PURPOSE: Delete a todo after user confirmation
 *
 * PARAMETERS:
 * @param {number} id - The ID of the todo to delete
 */
async function handleDelete(id) {
    const todo = todos.find(t => t.id === id);
    if (!todo) return;
    
    /*
     * CONFIRMATION DIALOG:
     * confirm() shows a browser dialog with OK/Cancel buttons
     * Returns true if user clicks OK, false if Cancel
     */
    const confirmed = confirm(`Are you sure you want to delete "${todo.title}"?`);
    if (confirmed) {
        await deleteTodo(id);
    }
}

// ===================================
// RENDER FUNCTIONS
// ===================================

/*
 * RENDERING:
 * These functions update the DOM (what the user sees) based on our data
 */

/*
 * renderTodos()
 * 
 * PURPOSE: Display todos in the UI based on current filter
 * 
 * HOW IT WORKS:
 * 1. Get filtered todos based on current filter
 * 2. If no todos, show empty state
 * 3. Otherwise, generate HTML for each todo
 * 4. Insert HTML into the DOM
 */
function renderTodos() {
    const filteredTodos = getFilteredTodos();
    
    // Show empty state if no todos match filter
    if (filteredTodos.length === 0) {
        todoList.innerHTML = '';
        emptyState.classList.remove('hidden');
        return;
    }
    
    emptyState.classList.add('hidden');
    
    /*
     * TEMPLATE LITERALS:
     * Backticks (`) allow us to create multi-line strings with embedded expressions
     * ${expression} inserts the value of the expression into the string
     * 
     * MAP:
     * map() transforms each todo into an HTML string
     * join('') combines all strings into one
     */
    todoList.innerHTML = filteredTodos.map(todo => `
        <div class="todo-item ${todo.completed ? 'completed' : ''}" data-id="${todo.id}">
            <input 
                type="checkbox" 
                ${todo.completed ? 'checked' : ''} 
                onchange="handleToggleComplete(${todo.id})"
                class="todo-checkbox"
                aria-label="Mark as ${todo.completed ? 'incomplete' : 'complete'}"
            >
            <div class="todo-content">
                <h3 class="todo-title">${escapeHtml(todo.title)}</h3>
                ${todo.description ? `<p class="todo-description">${escapeHtml(todo.description)}</p>` : ''}
                <span class="todo-date">${formatDate(todo.created_at)}</span>
            </div>
            <div class="todo-actions">
                <button 
                    onclick="handleEdit(${todo.id})" 
                    class="icon-btn edit-btn" 
                    title="Edit todo"
                    aria-label="Edit todo"
                >
                    ✏️
                </button>
                <button 
                    onclick="handleDelete(${todo.id})" 
                    class="icon-btn delete-btn" 
                    title="Delete todo"
                    aria-label="Delete todo"
                >
                    🗑️
                </button>
            </div>
        </div>
    `).join('');
}

/*
 * getFilteredTodos()
 * 
 * PURPOSE: Return todos based on current filter
 * 
 * RETURNS: Array of todos that match the current filter
 */
function getFilteredTodos() {
    switch (currentFilter) {
        case 'active':
            // filter() returns array of items where condition is true
            return todos.filter(todo => !todo.completed);
        case 'completed':
            return todos.filter(todo => todo.completed);
        default:
            return todos;
    }
}

/*
 * updateStats()
 * 
 * PURPOSE: Update the statistics cards (Total, Active, Completed)
 * 
 * HOW IT WORKS:
 * 1. Count total todos
 * 2. Count active (not completed) todos
 * 3. Count completed todos
 * 4. Update the DOM with new counts
 */
function updateStats() {
    const total = todos.length;
    const active = todos.filter(todo => !todo.completed).length;
    const completed = todos.filter(todo => todo.completed).length;
    
    // textContent sets the text inside an element
    totalCount.textContent = total;
    activeCount.textContent = active;
    completedCount.textContent = completed;
}

// ===================================
// MODAL FUNCTIONS
// ===================================

/*
 * showModal()
 * 
 * PURPOSE: Display the edit modal
 */
function showModal() {
    editModal.classList.remove('hidden');
    editTitle.focus();  // Put cursor in title field
}

/*
 * hideModal()
 * 
 * PURPOSE: Hide the edit modal and reset its state
 */
function hideModal() {
    editModal.classList.add('hidden');
    editForm.reset();
    editingTodoId = null;
}

// ===================================
// UI HELPER FUNCTIONS
// ===================================

/*
 * showLoading()
 * 
 * PURPOSE: Show or hide the loading spinner
 * 
 * PARAMETERS:
 * @param {boolean} show - true to show, false to hide
 */
function showLoading(show) {
    if (show) {
        loadingSpinner.classList.remove('hidden');
    } else {
        loadingSpinner.classList.add('hidden');
    }
}

/*
 * showError()
 * 
 * PURPOSE: Display an error message to the user
 * 
 * PARAMETERS:
 * @param {string} message - The error message to display
 * 
 * HOW IT WORKS:
 * 1. Set the error text
 * 2. Show the error message
 * 3. Auto-hide after 5 seconds using setTimeout
 */
function showError(message) {
    errorText.textContent = message;
    errorMessage.classList.remove('hidden');
    
    /*
     * SETTIMEOUT:
     * Executes a function after a specified delay (in milliseconds)
     * 5000ms = 5 seconds
     */
    setTimeout(() => {
        hideError();
    }, 5000);
}

/*
 * hideError()
 * 
 * PURPOSE: Hide the error message
 */
function hideError() {
    errorMessage.classList.add('hidden');
}

// ===================================
// UTILITY FUNCTIONS
// ===================================

/*
 * escapeHtml()
 * 
 * PURPOSE: Prevent XSS (Cross-Site Scripting) attacks
 * 
 * HOW IT WORKS:
 * When we insert user input into HTML, we need to escape special characters
 * like <, >, &, etc. to prevent malicious code injection
 * 
 * EXAMPLE:
 * Input: "<script>alert('hack')</script>"
 * Output: "<script>alert('hack')</script>"
 * 
 * The browser will display the text instead of executing it as code
 * 
 * PARAMETERS:
 * @param {string} text - The text to escape
 * @returns {string} The escaped text
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;  // textContent automatically escapes HTML
    return div.innerHTML;
}

/*
 * formatDate()
 * 
 * PURPOSE: Convert timestamp to human-readable relative time
 * 
 * EXAMPLES:
 * - "Just now" (< 1 minute ago)
 * - "5 minutes ago"
 * - "2 hours ago"
 * - "3 days ago"
 * - "Jan 15, 2024, 10:30 AM" (> 7 days ago)
 * 
 * PARAMETERS:
 * @param {string} dateString - ISO 8601 date string from backend
 * @returns {string} Human-readable relative time
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    
    // Calculate time difference in milliseconds
    const diffMs = now - date;
    
    // Convert to different units
    const diffMins = Math.floor(diffMs / 60000);      // 60000ms = 1 minute
    const diffHours = Math.floor(diffMs / 3600000);   // 3600000ms = 1 hour
    const diffDays = Math.floor(diffMs / 86400000);   // 86400000ms = 1 day
    
    // Return appropriate format based on how long ago
    if (diffMins < 1) {
        return 'Just now';
    } else if (diffMins < 60) {
        return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    } else if (diffHours < 24) {
        return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else if (diffDays < 7) {
        return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    } else {
        // For older dates, show full date and time
        return date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
}

// ===================================
// KEYBOARD SHORTCUTS
// ===================================

/*
 * KEYBOARD SHORTCUTS:
 * Enhance user experience with keyboard shortcuts
 */
document.addEventListener('keydown', (e) => {
    /*
     * Ctrl/Cmd + K: Focus on todo input
     * 
     * WHY: Power users prefer keyboard shortcuts
     * metaKey = Cmd on Mac, ctrlKey = Ctrl on Windows/Linux
     */
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();  // Prevent browser's default Ctrl+K action
        todoTitle.focus();
    }
});

// ===================================
// SERVICE WORKER (OPTIONAL)
// ===================================

/*
 * SERVICE WORKER:
 * Enables offline functionality and caching
 * 
 * WHY COMMENTED OUT: Service workers require HTTPS in production
 * and add complexity. Uncomment when ready to implement offline support.
 */
if ('serviceWorker' in navigator) {
    // Uncomment to enable service worker
    // navigator.serviceWorker.register('/sw.js')
    //     .then(reg => console.log('Service Worker registered'))
    //     .catch(err => console.log('Service Worker registration failed'));
}

// ===================================
// EXPORT FUNCTIONS FOR INLINE HANDLERS
// ===================================

/*
 * GLOBAL SCOPE:
 * These functions are called from inline event handlers in the HTML
 * (onclick attributes). We need to expose them to the global window object.
 * 
 * WHY: Inline handlers like onclick="handleEdit(1)" look for functions
 * in the global scope (window object)
 */
window.handleToggleComplete = handleToggleComplete;
window.handleEdit = handleEdit;
window.handleDelete = handleDelete;

/*
 * ===================================
 * END OF FILE
 * ===================================
 * 
 * SUMMARY OF KEY CONCEPTS:
 * 
 * 1. ASYNC/AWAIT: Handle asynchronous operations cleanly
 * 2. FETCH API: Make HTTP requests to backend
 * 3. ERROR HANDLING: try/catch blocks for robust error management
 * 4. DOM MANIPULATION: Update UI based on data
 * 5. EVENT LISTENERS: Respond to user interactions
 * 6. STATE MANAGEMENT: Keep track of application data
 * 7. TEMPLATE LITERALS: Generate dynamic HTML
 * 8. ARRAY METHODS: map(), filter(), find() for data manipulation
 * 
 * NEXT STEPS FOR LEARNING:
 * - Study the Fetch API documentation
 * - Learn about Promises and async/await in depth
 * - Explore modern JavaScript frameworks (React, Vue, Angular)
 * - Learn about state management libraries (Redux, MobX)
 * - Study REST API design principles
 */

// Made with Bob
